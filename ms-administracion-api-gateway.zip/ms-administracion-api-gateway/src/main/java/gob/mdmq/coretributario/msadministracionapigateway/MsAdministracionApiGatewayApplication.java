package gob.mdmq.coretributario.msadministracionapigateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsAdministracionApiGatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsAdministracionApiGatewayApplication.class, args);
	}

}
