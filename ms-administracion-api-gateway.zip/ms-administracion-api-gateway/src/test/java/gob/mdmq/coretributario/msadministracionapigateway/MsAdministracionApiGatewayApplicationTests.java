package gob.mdmq.coretributario.msadministracionapigateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAdministracionApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
