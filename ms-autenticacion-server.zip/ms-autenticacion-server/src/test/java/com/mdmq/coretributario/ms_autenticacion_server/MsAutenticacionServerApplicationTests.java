package com.mdmq.coretributario.ms_autenticacion_server;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsAutenticacionServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
