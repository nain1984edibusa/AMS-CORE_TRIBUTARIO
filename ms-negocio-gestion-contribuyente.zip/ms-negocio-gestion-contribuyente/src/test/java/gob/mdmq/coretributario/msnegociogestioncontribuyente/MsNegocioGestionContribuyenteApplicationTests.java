package gob.mdmq.coretributario.msnegociogestioncontribuyente;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsNegocioGestionContribuyenteApplicationTests {

	@Test
	void contextLoads() {
	}

}
