package gob.mdmq.coretributario.msnegociogestiontributo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsNegocioGestionTributoApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsNegocioGestionTributoApplication.class, args);
	}

}
