package gob.mdmq.coretributario.msparametrizacion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsParametrizacionApplicationTests {

	@Test
	void contextLoads() {
	}

}
